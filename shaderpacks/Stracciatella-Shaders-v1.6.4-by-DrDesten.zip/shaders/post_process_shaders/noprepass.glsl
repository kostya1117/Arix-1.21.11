#if ! defined INCLUDE_NOPREPASS_GLSL_12DA
#define INCLUDE_NOPREPASS_GLSL_12DA

/*
// Post Process Shaders
const int colortex7Format = R8;
*/

/* DRAWBUFFERS:7 */
layout(location = 0) out vec4 FragOut0;
void main() {}

#endif