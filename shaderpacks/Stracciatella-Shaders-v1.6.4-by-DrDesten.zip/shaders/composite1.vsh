#if ! defined INCLUDE_COMPOSITE1_VSH_5176
#define INCLUDE_COMPOSITE1_VSH_5176

#include "/lib/vertex_transform_composite.glsl"

out vec2 coord;

void main() {
	coord = gl_Vertex.xy / 2;

	gl_Position = getPosition();
	gl_Position.xy /= 4;
	gl_Position.xy -= 1./2. + 1./4.;
}

#endif