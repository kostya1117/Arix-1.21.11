#ifndef CORE_DH_UNIFORMS
#define CORE_DH_UNIFORMS

#if defined DISTANT_HORIZONS
#if ! defined INCLUDE_UNIFORM_float_dhNearPlane
#define INCLUDE_UNIFORM_float_dhNearPlane
uniform float dhNearPlane; 
#endif

#if ! defined INCLUDE_UNIFORM_float_dhFarPlane
#define INCLUDE_UNIFORM_float_dhFarPlane
uniform float dhFarPlane; 
#endif

#if ! defined INCLUDE_UNIFORM_int_dhRenderDistance
#define INCLUDE_UNIFORM_int_dhRenderDistance
uniform int dhRenderDistance; 
#endif

#if ! defined INCLUDE_UNIFORM_mat4_dhProjection
#define INCLUDE_UNIFORM_mat4_dhProjection
uniform mat4 dhProjection; 
#endif

#if ! defined INCLUDE_UNIFORM_mat4_dhProjectionInverse
#define INCLUDE_UNIFORM_mat4_dhProjectionInverse
uniform mat4 dhProjectionInverse; 
#endif

#if ! defined INCLUDE_UNIFORM_mat4_dhPreviousProjection
#define INCLUDE_UNIFORM_mat4_dhPreviousProjection
uniform mat4 dhPreviousProjection; 
#endif
#endif

#endif