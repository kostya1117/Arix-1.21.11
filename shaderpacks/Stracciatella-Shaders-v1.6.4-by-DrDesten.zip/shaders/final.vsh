#if ! defined INCLUDE_FINAL_VSH_1126
#define INCLUDE_FINAL_VSH_1126

#include "/lib/vertex_transform_composite.glsl"

void main() {
	gl_Position = getPosition();
}

#endif