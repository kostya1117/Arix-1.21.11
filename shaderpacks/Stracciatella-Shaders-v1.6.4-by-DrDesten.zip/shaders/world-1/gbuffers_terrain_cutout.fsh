#version 150 compatibility
#extension GL_ARB_explicit_attrib_location : enable
#define CUTOUT
#define FRAG
#define NETHER
#include "/gbuffers_terrain.fsh"
