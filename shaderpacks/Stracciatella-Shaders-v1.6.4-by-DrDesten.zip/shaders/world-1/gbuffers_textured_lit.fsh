#version 150 compatibility
#extension GL_ARB_explicit_attrib_location : enable
#define LIT
#define FRAG
#define NETHER
#include "/gbuffers_textured.fsh"
