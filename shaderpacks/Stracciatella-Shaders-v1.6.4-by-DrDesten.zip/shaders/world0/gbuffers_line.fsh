#version 130
#extension GL_ARB_explicit_attrib_location : enable
#define FRAG
#define OVERWORLD
#include "/gbuffers_line.fsh"
