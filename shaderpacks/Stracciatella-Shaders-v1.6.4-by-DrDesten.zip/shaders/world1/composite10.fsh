#version 150 compatibility
#extension GL_ARB_explicit_attrib_location : enable
#define FRAG
#define END
#include "/composite10.fsh"
