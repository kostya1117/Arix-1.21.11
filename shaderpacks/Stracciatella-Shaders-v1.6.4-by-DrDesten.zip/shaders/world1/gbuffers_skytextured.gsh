#version 150 compatibility
#extension GL_ARB_explicit_attrib_location : enable
#define GEO
#define END
#include "/gbuffers_skytextured.gsh"
