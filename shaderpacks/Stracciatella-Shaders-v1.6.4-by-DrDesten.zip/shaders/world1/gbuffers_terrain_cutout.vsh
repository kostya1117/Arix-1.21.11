#version 150 compatibility
#extension GL_ARB_explicit_attrib_location : enable
#define CUTOUT
#define VERT
#define END
#include "/gbuffers_terrain.vsh"
