#if ! defined INCLUDE_COMPOSITE5_VSH_DBFA
#define INCLUDE_COMPOSITE5_VSH_DBFA

#include "/lib/vertex_transform_composite.glsl"

void main() {
	gl_Position = getPosition();
}

#endif