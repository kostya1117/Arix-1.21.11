#include "/lib/config.glsl"
const bool colortex1MipmapEnabled = true;

/* Color utils */

#ifdef THE_END
    #include "/lib/color_utils_end.glsl"
#elif defined NETHER
    #include "/lib/color_utils_nether.glsl"
#else
    #include "/lib/color_utils.glsl"
#endif

/* Uniforms */

uniform sampler2D colortex1;
uniform float far;
uniform float near;
uniform float blindness;
uniform float rainStrength;
uniform float wetness;
uniform sampler2D depthtex0;
uniform int isEyeInWater;
uniform ivec2 eyeBrightnessSmooth;
uniform float frameTime;
uniform float viewWidth;
uniform float viewHeight;
uniform int frameCounter;

#if MC_VERSION >= 11900
    uniform float darknessFactor;
#endif

#if (VOL_LIGHT == 2 && defined FSR) || VOL_LIGHT == 1 && !defined NETHER
    uniform sampler2D depthtex1;
    uniform vec3 sunPosition;
    uniform vec3 moonPosition;
    uniform float light_mix;
    uniform mat4 gbufferProjectionInverse;
    uniform mat4 gbufferModelViewInverse;
    uniform mat4 gbufferModelView;
    uniform mat4 gbufferProjection; // Added for Screen Space Sun/Moon
    uniform float vol_mixer;
#endif

#if VOL_LIGHT == 2 && defined SHADOW_CASTING && !defined NETHER && !defined FSR
    uniform float light_mix;
    uniform mat4 gbufferProjectionInverse;
    uniform mat4 gbufferModelViewInverse;
    uniform mat4 gbufferModelView;
    uniform float vol_mixer;
    uniform vec3 shadowLightPosition;
    uniform mat4 shadowModelView;
    uniform mat4 shadowProjection;
    uniform sampler2DShadow shadowtex1;

    #if defined COLORED_SHADOW
        uniform sampler2DShadow shadowtex0;
        uniform sampler2D shadowcolor0;
    #endif
#endif

/* Ins / Outs */

varying vec2 texcoord;
varying vec3 direct_light_color;
varying vec3 direct_light_strength;
varying float exposure;

#if (VOL_LIGHT == 2 && defined FSR) || VOL_LIGHT == 1 && !defined NETHER
    varying vec3 vol_light_color;
    varying vec2 lightpos;
    varying vec3 astro_pos;
#endif

#if VOL_LIGHT == 2 && defined SHADOW_CASTING && !defined NETHER && !defined FSR
    varying vec3 vol_light_color;
#endif

#if (VOL_LIGHT == 1 && !defined NETHER) || (VOL_LIGHT == 2 && defined SHADOW_CASTING && !defined NETHER)
    varying mat4 modeli_times_projectioni;
#endif

/* Utility functions */

#include "/lib/fps_correction.glsl"
#include "/lib/basic_utils.glsl"
#include "/lib/depth.glsl"

#ifdef BLOOM
    #include "/lib/luma.glsl"
#endif

#define FRAGMENT
#include "/lib/downscale.glsl"

#if (VOL_LIGHT == 1 || (VOL_LIGHT == 2 && defined FSR)) && !defined NETHER
    #include "/lib/dither.glsl"
    #include "/lib/volumetric_light.glsl"
#endif

#if VOL_LIGHT == 2 && defined SHADOW_CASTING && !defined NETHER && !defined FSR
    #include "/lib/dither.glsl"
    #include "/lib/volumetric_light.glsl"
#endif

// --- NOISE FUNCTIONS FOR MOON TEXTURE (VORONOI / CRATERS) ---
vec2 moon_hash22(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * vec3(.1031, .1030, .0973));
    p3 += dot(p3, p3.yzx+33.33);
    return fract((p3.xx+p3.yz)*p3.zy);
}

// Cellular Noise (Voronoi) - Good for Craters
float moon_voronoi(vec2 x) {
    vec2 n = floor(x);
    vec2 f = fract(x);
    float m = 8.0;
    for(int j=-1; j<=1; j++)
    for(int i=-1; i<=1; i++) {
        vec2 g = vec2(float(i),float(j));
        vec2 o = moon_hash22( n + g );
        // Animate? No, static moon.
        // vec2 r = g - f + (0.5+0.5*sin(frameTimeCounter+6.2831*o));
        vec2 r = g - f + o;
        float d = dot(r,r);
        if( d<m ) m=d;
    }
    return m;
}

// FBM for Maria (Dark patches) - Keep standard noise for this
float moon_hash12_low(vec2 p) {
    vec3 p3  = fract(vec3(p.xyx) * .1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}
float moon_noise_low(in vec2 x) {
    vec2 p = floor(x);
    vec2 f = fract(x);
    f = f*f*(3.0-2.0*f);
    float res = mix(mix( moon_hash12_low(p), moon_hash12_low(p + vec2(1.0, 0.0)), f.x),
                    mix( moon_hash12_low(p + vec2(0.0, 1.0)), moon_hash12_low(p + vec2(1.0, 1.0)), f.x), f.y);
    return res;
}
float moon_fbm_low(vec2 p) {
    float f = 0.0; float w = 0.5;
    for (int i = 0; i < 4; i++) { f += w * moon_noise_low(p); p *= 2.0; w *= 0.5; }
    return f;
}
// ----------------------------------------

// MAIN FUNCTION ------------------

void main() {
    vec4 block_color = texture2DLod(colortex1, texcoord, 0);
    float d = texture2DLod(depthtex0, texcoord, 0).r;
    float linear_d = ld(d);

    vec2 eye_bright_smooth = vec2(eyeBrightnessSmooth);

    // Depth to distance
    float screen_distance = linear_d * far * 0.5;
    
    #if defined THE_END || defined NETHER
        #define NIGHT_CORRECTION 1.0
        #define COLOR_CORRECTION day_blend(vec3(1.0, 0.8, 1.0), vec3(1.0), vec3(1.0, 0.6, 1.0))
    #else
        #define NIGHT_CORRECTION day_blend_float(0.5, 0.75, 5.0)
        #define COLOR_CORRECTION day_blend(vec3(1.0, 0.8, 1.0), vec3(1.0), vec3(1.0, 0.6, 1.0))
    #endif

    // Underwater fog
    // Pre-calculating values.
    float water_absorption_exponent_val = WATER_FOG + (WATER_ABSORPTION * 4.0);
    float eye_brightness_scaled_val = (eye_bright_smooth.y * .8 + 48.0) * 0.004166666666666667;
    vec3 water_light_color_base = NIGHT_CORRECTION * WATER_COLOR * COLOR_CORRECTION * direct_light_strength;

    if(isEyeInWater == 1) {
        float water_absorption = clamp(-pow((-linear_d + 1.0), water_absorption_exponent_val) + 1.0, 0.0, 1.0);

        block_color.rgb =
            mix(block_color.rgb, water_light_color_base * eye_brightness_scaled_val, water_absorption);

    } else if(isEyeInWater == 2) {
        block_color = mix(block_color, vec4(1.0, .1, 0.0, 1.0), clamp(sqrt(linear_d * (far * 0.125)), 0.0, 1.0));
    }

    #if MC_VERSION >= 11900
        if((blindness > .01 || darknessFactor > .01) && linear_d > 0.999) {
            block_color.rgb = vec3(0.0);
        }
    #else
        if(blindness > .01 && linear_d > 0.999) {
            block_color.rgb = vec3(0.0);
        }
    #endif

    #if (VOL_LIGHT == 1 && !defined NETHER) || (VOL_LIGHT == 2 && !defined NETHER)
        #if AA_TYPE > 0
            float dither = shifted_eclectic_r_dither(gl_FragCoord.xy);
        #else
            float dither = r_dither(gl_FragCoord.xy);
        #endif
    #endif

    #if (VOL_LIGHT == 1 || (VOL_LIGHT == 2 && defined FSR)) && !defined NETHER
        #if defined THE_END
            #if MC_VERSION < 11604
                float vol_light = 0.0;
            #else
                float vol_light = ss_godrays(dither) * 0.4;
            #endif
        #else
            float vol_light = ss_godrays(dither);
        #endif

        vec4 center_world_pos = modeli_times_projectioni * (vec4(0.5, 0.5, 1.0, 1.0) * 2.0 - 1.0);
        vec3 center_view_vector = normalize(center_world_pos.xyz);

        vec4 world_pos = modeli_times_projectioni * (vec4(texcoord / RENDER_SCALE, 1.0, 1.0) * 2.0 - 1.0);
        vec3 view_vector = normalize(world_pos.xyz);

        #if defined THE_END
            // Fixed light source position in sky for intensity calculation
            vec3 intermediate_vector =
                normalize((gbufferModelViewInverse * gbufferModelView * vec4(0.0, 0.89442719, 0.4472136, 0.0)).xyz);
            float vol_intensity =
                clamp(dot(center_view_vector, intermediate_vector), 0.0, 1.0);

            vol_intensity *= clamp(dot(view_vector, intermediate_vector), 0.0, 1.0);

            vol_intensity *= 0.666;

            // Balanced volumetric intensity for visible god rays
            block_color.rgb += (vol_light_color * vol_light * vol_intensity * 0.2);
        #else
            // Light source position for depth based godrays intensity calculation
            vec3 intermediate_vector =
                normalize((gbufferModelViewInverse * vec4(astro_pos, 0.0)).xyz);
            float vol_intensity =
                clamp(dot(center_view_vector, intermediate_vector), 0.0, 1.0);
            vol_intensity *= dot(view_vector, intermediate_vector);
            vol_intensity =
                pow(clamp(vol_intensity, 0.0, 1.0), vol_mixer) * 0.5 * clamp(abs(light_mix * 3.0 - 1.0), 0.0, 1.0);
            vol_intensity *= 0.666;
            // Balanced volumetric intensity for visible god rays
            block_color.rgb =
                mix(block_color.rgb, vol_light_color * vol_light, vol_intensity * vol_light * 0.25 * (1.0 - rainStrength));
        #endif
    #endif

    #if VOL_LIGHT == 2 && defined SHADOW_CASTING && !defined NETHER && !defined FSR
        #if defined COLORED_SHADOW
            vec3 vol_light = get_volumetric_color_light(dither, screen_distance, modeli_times_projectioni);
        #else
            float vol_light = get_volumetric_light(dither, screen_distance, modeli_times_projectioni);
        #endif
        // Volumetric intensity adjustments

        vec4 world_pos = modeli_times_projectioni * (vec4(texcoord, 1.0, 1.0) * 2.0 - 1.0);
        vec3 view_vector = normalize(world_pos.xyz);

        #if defined THE_END
            // Fixed light source position in sky for volumetrics intensity calculation (The End)
            float vol_intensity = dot(view_vector, normalize((gbufferModelViewInverse * gbufferModelView * vec4(0.0, 0.89442719, 0.4472136, 0.0)).xyz));
        #else
            // Light source position for volumetrics intensity calculation
            float vol_intensity = dot(view_vector, normalize((gbufferModelViewInverse * vec4(shadowLightPosition, 0.0)).xyz));
        #endif

        #if defined THE_END
            vol_intensity =
                ((square_pow(clamp((vol_intensity + .666667) * 0.6, 0.0, 1.0)) * 0.5));
            // Balanced volumetric intensity for visible god rays
            block_color.rgb += (vol_light_color * vol_light * vol_intensity * 0.2);
        #else
            vol_intensity =
                pow(clamp((vol_intensity + 0.5) * 0.666666666666666, 0.0, 1.0), vol_mixer) * 0.6 * abs(light_mix * 2.0 - 1.0);

            // Balanced volumetric intensity
            block_color.rgb =
                mix(block_color.rgb, vol_light_color * vol_light, vol_intensity * (vol_light * 0.15 + 0.1) * (1.0 - rainStrength));
        #endif
    #endif
    
    // Dentro de la nieve
    #ifdef BLOOM
        if(isEyeInWater == 3) {
            block_color.rgb =
                mix(block_color.rgb, vec3(0.7, 0.8, 1.0) / exposure, clamp(screen_distance, 0.0, 1.0));
        }
    #else
        if(isEyeInWater == 3) {
            block_color.rgb =
                mix(block_color.rgb, vec3(0.85, 0.9, 0.6), clamp(screen_distance, 0.0, 1.0));
        }
    #endif

    // --- SCREEN SPACE SUN & MOON (FOV FIX) ---
    // Only render sun/moon in Overworld (not in Nether or End)
    #if ((VOL_LIGHT == 2 && defined FSR) || VOL_LIGHT == 1) && !defined NETHER && !defined THE_END
        

        // Check if sunPosition is valid (w > 0 check on screen projection)
        // sunPosition IS in View Space (relative to camera) in Optifine.
        
        vec4 sunClipPos = gbufferProjection * vec4(sunPosition, 1.0);
        vec3 sunScreenPos = sunClipPos.xyz / sunClipPos.w;
        vec2 sunScreen = sunScreenPos.xy * 0.5 + 0.5;

        // Moon is opposite render
        vec4 moonClipPos = gbufferProjection * vec4(-sunPosition, 1.0);
        vec3 moonScreenPos = moonClipPos.xyz / moonClipPos.w;
        vec2 moonScreen = moonScreenPos.xy * 0.5 + 0.5;

        float aspectRatio = viewWidth / viewHeight;
        
        // Depth Check (Don't draw over blocks)
        if (linear_d > 0.99) { // Only draw on sky (far plane)
            // Weather Visibility Factor (Hide during rain)
            float weatherVisibility = 1.0 - rainStrength;
            
            // --- DRAW SUN ---
            if (sunClipPos.w > 0.0) { // In front of camera
                vec2 distVec = (texcoord - sunScreen);
                distVec.x *= aspectRatio;
                float dist = length(distVec);
                
                float sunRad = 0.028; // Sun Radius (Visible size)
                if (dist < sunRad) {
                    float edge = fwidth(dist) * 2.0;
                    float alpha = smoothstep(sunRad, sunRad - edge, dist);
                    
                    // Texture Mapping for Solar Granulation
                    vec2 sunUV = distVec * 500.0; // Higher frequency for fine detail
                    
                    // Solar Granulation (Convection cells)
                    float granulation = moon_voronoi(sunUV * 2.0);
                    granulation = smoothstep(0.1, 0.6, granulation);
                    
                    // Add turbulence
                    float turbulence = moon_fbm_low(sunUV * 1.5);
                    
                    // Radial gradient from center
                    float grad = 1.0 - (dist / sunRad);
                    
                    // Color palette
                    vec3 sunCore = vec3(1.0, 1.0, 0.9);      // Bright yellow-white center
                    vec3 sunMid = vec3(1.0, 0.85, 0.4);      // Yellow
                    vec3 sunEdge = vec3(1.0, 0.5, 0.1);      // Orange-red edge
                    
                    // Base color with limb darkening
                    vec3 sunColor = mix(sunEdge, sunCore, pow(grad, 0.4));
                    
                    // Apply granulation (darker spots)
                    sunColor *= 0.7 + 0.3 * granulation;
                    
                    // Apply turbulence (variation)
                    sunColor *= 0.85 + 0.15 * turbulence;
                    
                    // Brightness (much lower to reveal texture)
                    sunColor *= 1.2;
                    
                    // Clamp to prevent color artifacts
                    sunColor = clamp(sunColor, vec3(0.0), vec3(10.0));
                    
                    // Apply Weather Visibility
                    alpha *= weatherVisibility;
                    
                    block_color.rgb = mix(block_color.rgb, sunColor, alpha);
                }
                
                // Sun Glow (Halo)
                float glowRad = 0.12;
                if (dist < glowRad) {
                    float glow = smoothstep(glowRad, sunRad, dist);
                    // Reduced glow intensity for balance + Weather Visibility
                    block_color.rgb += vec3(1.0, 0.8, 0.4) * glow * 0.3 * weatherVisibility; 
                }
            }

            // --- DRAW MOON ---
            if (moonClipPos.w > 0.0) { // In front of camera
                vec2 distVec = (texcoord - moonScreen);
                distVec.x *= aspectRatio;
                float dist = length(distVec);
                
                float moonRad = 0.028; // Moon Radius (Same size as Sun)
                
                // Draw Body
                if (dist < moonRad + 0.005) {
                    float edge = fwidth(dist) * 2.0;
                    float alpha = smoothstep(moonRad, moonRad - edge, dist);
                    
                    // Texture Mapping
                    vec2 moonUV = distVec * 400.0; // Scale
                    
                    // 1. Craters (Voronoi)
                    // Voronoi returns distance to center. Invert for craters.
                    float v = moon_voronoi(moonUV * 1.5);
                    // Sharp edge craters
                    float craters = smoothstep(0.1, 0.4, v); 
                    
                    // 2. Maria (Dark Patches - FBM)
                    float mareNoise = moon_fbm_low(moonUV * 0.3 + vec2(8.0));
                    float mare = smoothstep(0.4, 0.7, mareNoise);
                    
                    // 3. Composite Colors (Reference Image Match)
                    // The reference is a cold, pale blue-grey with dark grey seas.
                    
                    vec3 colBright = vec3(0.9, 0.95, 1.0); // Pale Blue-White (Highlands)
                    vec3 colDark   = vec3(0.4, 0.45, 0.5); // Dark Grey-Blue (Maria)
                    vec3 colCrater = vec3(0.6, 0.65, 0.7); // Shadow inside craters
                    
                    // Base: Highlands vs Maria
                    vec3 moonColor = mix(colBright, colDark, mare);
                    
                    // Apply Craters (Small distinct dots)
                    // If 'craters' is low, it's a hole.
                    float craterMask = 1.0 - smoothstep(0.0, 0.2, v); // Points are 1.0
                    moonColor = mix(moonColor, colCrater, craterMask * 0.7);
                    
                    // 4. Falloff / Limb Darkening (Sphere shape)
                    float sphereGrad = sqrt(1.0 - clamp(dist/moonRad, 0.0, 1.0)); // Spherical normal Z
                    moonColor *= 0.5 + 0.5 * sphereGrad; // Shadow at edges
                   
                    // Brightness (Controlled - No Burn)
                    // Further reduced to 0.5 to show maximum crater detail
                    moonColor *= 0.5;
                    
                    // Apply Weather Visibility
                    alpha *= weatherVisibility;
                    
                    block_color.rgb = mix(block_color.rgb, moonColor, alpha);
                }
                 
                // Moon Glow (Separate)
                float glowRad = 0.15;
                if (dist < glowRad) {
                    float glow = smoothstep(glowRad, moonRad, dist);
                    // Subtle Glow (Reduced intensity from 1.5 to 0.4) + Weather Visibility
                    block_color.rgb += vec3(0.1, 0.3, 1.0) * glow * 0.4 * weatherVisibility;
                }
            }
        }
    #endif

    #ifdef BLOOM
        // Bloom source
        float bloom_luma;
        if(fragment_cull()){
            bloom_luma = 0.0;
        } else {
            bloom_luma = smoothstep(0.85, 1.0, luma(block_color.rgb * exposure)) * 0.5;
        }
        block_color = clamp(block_color, vec4(0.0), vec4(vec3(50.0), 1.0));     
        /* DRAWBUFFERS:146 */
        gl_FragData[0] = block_color;
        gl_FragData[1] = block_color * bloom_luma;
        gl_FragData[2] = vec4(exposure, 0.0, 0.0, 0.0);
    #else
        block_color = clamp(block_color, vec4(0.0), vec4(vec3(50.0), 1.0));
        /* DRAWBUFFERS:16 */
        gl_FragData[0] = block_color;
        gl_FragData[1] = vec4(exposure, 0.0, 0.0, 0.0);
    #endif
}