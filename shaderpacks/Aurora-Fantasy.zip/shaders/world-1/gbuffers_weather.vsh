#version 120
/* Aurora Fantasy - gbuffers_weather.vsh
Render: Weather

in2bubble - Based on MakeUp by KDXavier - GNU Lesser General Public License v3.0
*/

#define NETHER
#define GBUFFER_WEATHER
#define NO_SHADOWS

#include "/common/solid_blocks_vertex.glsl"