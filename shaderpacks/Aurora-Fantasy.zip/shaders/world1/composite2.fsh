#version 120
/* Aurora Fantasy - composite2.fsh
Render: Antialiasing

in2bubble - Based on MakeUp by KDXavier - GNU Lesser General Public License v3.0
*/

#define THE_END
#define COMPOSITE2_SHADER
#define NO_SHADOWS

#include "/common/composite2_fragment.glsl"
