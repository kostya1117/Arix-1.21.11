# ✨ Aurora Fantasy

A fantasy-themed shader pack for Minecraft Java Edition, based on the open-source MakeUp shader.

Designed to transform the game world into a stunning visual experience with optimized performance across various hardware.

---

## Features

- ☀️ Customizable realistic shadows with colored shadows for glass and ice
- ☁️ Volumetric clouds (static or dynamic) with a cirrus cloud layer
- 🌊 Realistic water waves with reflections and light refraction
- ⭐ Realistic stars with a procedural sun and moon
- 🌈 12+ color schemes with full custom color support
- 💎 Glowing ores and material gloss effects
- 🌅 Volumetric god rays and bloom
- 📸 Depth of field, motion blur, and AMD FSR 1.0 upscaling
- 🎬 Multiple tone mapping operators and smart TAA antialiasing
- 🍃 Wind-animated plants and leaves
- 🌫️ Biome-based fog and sandstorms
- 🌍 Full support for Overworld, Nether, The End, and modded dimensions

---

## Requirements

- Minecraft Java Edition 1.7.10 — 1.21+
- OptiFine or Iris Shaders
- GPU with OpenGL 2.1+ support

---

## Installation

Copy the shader folder into the shaderpacks directory inside .minecraft, then select it from the video settings in-game.

---

## Credits

- **in2bubble** — Shader modifier
- **KDXavier** — Original creator of MakeUp shader

---

## License

Licensed under the GNU Lesser General Public License v3.0
