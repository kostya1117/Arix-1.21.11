#version 120

#define END_SHADER

#define WORLD

// إضاءة إضافية لعالم التنين
#define BOOST_END_LIGHTING

#include "/dimensions/all_solid.fsh"