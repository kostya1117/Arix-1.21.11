/*******************************************************************************
 * LPV (Light Propagation Volumes) System - Unified File
 * 
 * This file combines all LPV and Voxel related functionality:
 * - lpv_blocks.glsl  : Block light data management
 * - lpv_common.glsl  : Common LPV constants and utilities
 * - lpv_buffer.glsl  : Image buffer definitions
 * - lpv_render.glsl  : LPV sampling and rendering
 * - voxel_common.glsl: Voxel grid management
 * - voxel_write.glsl : Voxel data writing
 ******************************************************************************/

// Ensure LPV_SIZE is defined (default value if not already defined)
#ifndef LPV_SIZE
    #define LPV_SIZE 7
#endif

// ============================================================================
// SECTION 1: Block Data Management (from lpv_blocks.glsl)
// ============================================================================

/*
    Block data structure:
    lightColor  3*8=24 bits
    lightRange  8=8 bits
    tintColor   3*8=24 bits
    lightMask   6=8 bits
*/

#ifdef RENDER_SETUP
    layout(rg32ui) writeonly uniform uimage1D imgBlockData;
#else
    layout(rg32ui) uniform uimage1D imgBlockData;
#endif

// ============================================================================
// SECTION 2: Common LPV Constants and Functions (from lpv_common.glsl)
// ============================================================================

// How far light propagates (block, sky)
const vec2 LpvBlockSkyRange = vec2(15.0, 24.0);

const uint LpvSize = uint(exp2(LPV_SIZE));
const uvec3 LpvSize3 = uvec3(LpvSize);

#ifndef RENDER_SETUP
    vec3 GetLpvPosition(const in vec3 playerPos) {
        vec3 cameraOffset = fract(cameraPosition);
        return playerPos + cameraOffset + LpvSize3/2u;
    }
#endif

// ============================================================================
// SECTION 3: LPV Buffer Definitions (from lpv_buffer.glsl)
// ============================================================================

#ifdef RENDER_SHADOWCOMP
	layout(rgba8) restrict uniform image3D imgLpv1;
	layout(rgba8) restrict uniform image3D imgLpv2;
#else
	layout(rgba8) uniform image3D imgLpv1;
	layout(rgba8) uniform image3D imgLpv2;
#endif

// ============================================================================
// SECTION 4: LPV Rendering Functions (from lpv_render.glsl)
// ============================================================================

// LPV block brightness scale
const float LpvBlockBrightness = 1.0;

float lpvCurve(float values) {
    // return values;
    return pow(1.0 - sqrt(1.0-values), 2.0);
}

vec4 SampleLpvLinear(const in vec3 lpvPos) {
    vec3 texcoord = lpvPos / LpvSize3;

    vec4 lpvSample = (frameCounter % 2) == 0
        ? textureLod(texLpv1, texcoord, 0)
        : textureLod(texLpv2, texcoord, 0);

    vec3 hsv = RgbToHsv(lpvSample.rgb);
    hsv.z = lpvCurve(hsv.b) * LpvBlockSkyRange.x;
    lpvSample.rgb = HsvToRgb(hsv);

    return lpvSample;
}

vec3 GetLpvBlockLight(const in vec4 lpvSample) {
    return LpvBlockBrightness * lpvSample.rgb;
}

float GetLpvSkyLight(const in vec4 lpvSample) {
    float skyLight = saturate(lpvSample.a);
    return skyLight*skyLight;
}

// ============================================================================
// SECTION 5: Voxel Grid Common (from voxel_common.glsl)
// ============================================================================

#ifdef RENDER_SHADOW
	layout(r16ui) uniform uimage3D imgVoxelMask;
#else
	layout(r16ui) uniform uimage3D imgVoxelMask;
#endif

const uint VoxelSize = uint(exp2(LPV_SIZE));
const uvec3 VoxelSize3 = uvec3(VoxelSize);

#define BLOCK_EMPTY 0

// ============================================================================
// SECTION 6: Voxel Writing Functions (from voxel_write.glsl)
// ============================================================================

#ifndef RENDER_SETUP
    ivec3 GetVoxelIndex(const in vec3 playerPos) {
        vec3 cameraOffset = fract(cameraPosition);
        return ivec3(floor(playerPos + cameraOffset) + VoxelSize3/2u);
    }

    void SetVoxelBlock(const in vec3 playerPos, const in uint blockId) {
        ivec3 voxelPos = GetVoxelIndex(playerPos);
        if (clamp(voxelPos, ivec3(0), ivec3(VoxelSize-1u)) != voxelPos) return;

        imageStore(imgVoxelMask, voxelPos, uvec4(blockId));
    }

    void PopulateShadowVoxel(const in vec3 playerPos) {
        uint voxelId = 0u;
        vec3 originPos = playerPos;

        if (
            renderStage == MC_RENDER_STAGE_TERRAIN_SOLID || renderStage == MC_RENDER_STAGE_TERRAIN_TRANSLUCENT ||
            renderStage == MC_RENDER_STAGE_TERRAIN_CUTOUT || renderStage == MC_RENDER_STAGE_TERRAIN_CUTOUT_MIPPED
        ) {
            voxelId = uint(mc_Entity.x + 0.5);

            #ifdef IRIS_FEATURE_BLOCK_EMISSION_ATTRIBUTE
                if (voxelId == 0u && at_midBlock.w > 0) voxelId = uint(BLOCK_LIGHT_1 + at_midBlock.w - 1);
            #endif

            if (voxelId == 0u) voxelId = 1u;

            originPos += at_midBlock.xyz/64.0;
        }
        
        #ifdef LPV_ENTITY_LIGHTS
            if (
                ((renderStage == MC_RENDER_STAGE_ENTITIES && (currentRenderedItemId > 0 || entityId > 0)) || renderStage == MC_RENDER_STAGE_BLOCK_ENTITIES)
            ) {
                if (renderStage == MC_RENDER_STAGE_BLOCK_ENTITIES) {
                    if (blockEntityId > 0 && blockEntityId < 500)
                        voxelId = uint(blockEntityId);
                }
                else if (currentRenderedItemId > 0 && currentRenderedItemId < 1200) {
                    if (entityId != ENTITY_ITEM_FRAME && entityId != ENTITY_PLAYER) {
                        uint blockDataR = texelFetch(texBlockData, currentRenderedItemId, 0).r;
                        float lightRange = unpackUnorm4x8(blockDataR).a * 255.0;

                        if (lightRange > 0.0)
                            voxelId = uint(currentRenderedItemId);
                    }
                }
                else {
                    switch (entityId) {
                        case ENTITY_BLAZE:
                        case ENTITY_END_CRYSTAL:
                        // case ENTITY_FIREBALL_SMALL:
                        case ENTITY_GLOW_SQUID:
                        case ENTITY_MAGMA_CUBE:
                        case ENTITY_SPECTRAL_ARROW:
                        case ENTITY_TNT:
                            voxelId = uint(entityId);
                            break;
                    }
                }
            }
        #endif

        if (voxelId > 0u)
            SetVoxelBlock(originPos, voxelId);
    }
#endif
