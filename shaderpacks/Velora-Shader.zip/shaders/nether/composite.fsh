// Velora Shader by Haider - Copyright (c) 2025
#version 120

#define NETHER_SHADER

#include "/dimensions/fogBehindTranslucent_pass.fsh"