// Velora Shader by Haider - Copyright (c) 2025
#version 330 compatibility

#define OVERWORLD_SHADER

#include "/dimensions/DH_translucent.vsh"