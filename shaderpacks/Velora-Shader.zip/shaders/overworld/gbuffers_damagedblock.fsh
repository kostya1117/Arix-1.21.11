// Velora Shader by Haider - Copyright (c) 2025
#version 120

#define DAMAGE_BLOCK_EFFECT

#include "/dimensions/all_particles.fsh"