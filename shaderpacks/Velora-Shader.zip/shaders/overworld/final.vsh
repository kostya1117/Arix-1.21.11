// Velora Shader by Haider - Copyright (c) 2025
#version 120

#include "/dimensions/final.vsh"