// Velora Shader by Haider - Copyright (c) 2025
#version 120

void main() {
	discard;
}
