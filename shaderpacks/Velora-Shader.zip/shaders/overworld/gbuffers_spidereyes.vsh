// Velora Shader by Haider - Copyright (c) 2025
#version 120

#define SPIDER_EYES

#include "/dimensions/all_vanilla_emissives.vsh"