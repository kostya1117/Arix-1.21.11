// Velora Shader by Haider - Copyright (c) 2025
#version 120

#define OVERWORLD_SHADER

#include "/dimensions/all_translucent.fsh"