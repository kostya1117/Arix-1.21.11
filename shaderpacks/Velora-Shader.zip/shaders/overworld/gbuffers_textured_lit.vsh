// Velora Shader by Haider - Copyright (c) 2025
#version 120

#define LIT
#define PARTICLES
#define OVERWORLD_SHADER

#include "/dimensions/all_particles.vsh"