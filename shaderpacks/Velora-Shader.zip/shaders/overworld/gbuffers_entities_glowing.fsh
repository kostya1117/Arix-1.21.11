// Velora Shader by Haider - Copyright (c) 2025
#version 120

#define GLOWING

#include "/dimensions/all_vanilla_emissives.fsh"