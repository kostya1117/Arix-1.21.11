// Velora Shader by Haider - Copyright (c) 2025
#version 120

#define OVERWORLD_SHADER

#define WORLD

#include "/dimensions/all_solid.vsh"