// Velora Shader by Haider - Copyright (c) 2025
#version 120

#define WORLD
#define HAND

#define OVERWORLD_SHADER

#include "/dimensions/all_solid.fsh"