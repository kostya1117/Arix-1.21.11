# Velora Shader

**A beautiful Minecraft shader pack by Haider**

## Features
- Enhanced lighting system with custom ambient brightness
- Volumetric fog effects across all dimensions  
- Optimized water rendering with wave effects
- Custom End dimension lighting with minimal brightness
- Atmospheric improvements for better immersion
- Removed unwanted effects like clouds and smoke for cleaner visuals

## Dimensions
- **Overworld**: Enhanced natural lighting and fog
- **Nether**: Optimized atmospheric effects 
- **End**: Custom lighting system with subtle illumination

## Installation
1. Install OptiFine or Iris mod
2. Place the shader folder in your shaderpacks directory
3. Select "Velora Shader" in your shader options

## Credits
Created by Haider - Copyright (c) 2025

---

*Velora Shader - Experience Minecraft with enhanced visual beauty*